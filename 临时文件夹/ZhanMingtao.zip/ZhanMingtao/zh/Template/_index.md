---

# （0）用一张照片覆盖掉本文件夹中的avatar.jpg

# （1）要显示的名字
# name to display
title: 詹明韬

# （2）与文件夹的名字相同。文件夹的名字应该是自己发论文时署名的全称。
# the same as the foldername, which should be the same as the papers' author name.
authors:
- Template

# Is this the primary user of the site?
superuser: false

# (3) 填写现在的身份/职业
# Role/position
role: 模拟IC设计高级工程师

# （3.1）若想写具体的公司/机构/部门，可以取消下面的注释以显示内容
# Organizations/Affiliations
organizations:
- name: 亚德诺半导体XX部门
  url: "https://www.analog.com/cn/index.html"

# （4）一两句话的简介，不过一般不会被显示
# Short bio (displayed in user profile at end of posts)
bio: 无

# （5）研究兴趣/领域/方向
interests:
- 模拟和混合信号集成电路
- 存内计算

# （6）学历情况
education:
  courses:
  - course: 学士（优秀毕业生）
    institution: 清华大学电子工程系
    year: 2020

# （7）联系方式，可以只写邮箱（如果需要的话也可以写twitter等）。把以下邮箱换掉即可
# Social/Academic Networking
social:
- icon: envelope
  icon_pack: fas
  link: 'zmt20@mails.tsinghua.edu.cn'  # For a direct email link, use "mailto:test@example.org".

# （7.1）也可以放个人网站、CV等连接……

# Highlight the author in author lists? (true/false)
highlight_name: true


# （8）显示分组。目前有三种选项：导师、团队、已毕业
# Organizational groups that you belong to (for People widget)
user_groups:
- 团队
---

<!-- 一段或者多段自我介绍，推荐100字以上。可以配图 -->
我目前是直博一年级，研究方向是高性能数据转换器和存内计算电路。